#pragma once

#include "ofMain.h"
#include "Envelope.hpp"


class ofApp : public ofBaseApp{
    
public:
    void setup();
    void update();
    void draw();
    void makeEnvelope();
    void makeWave();
    
    void keyPressed(int key);
    void keyReleased(int key);
    void mouseMoved(int x, int y );
    void mouseDragged(int x, int y, int button);
    void mousePressed(int x, int y, int button);
    void mouseReleased(int x, int y, int button);
    void mouseEntered(int x, int y);
    void mouseExited(int x, int y);
    void windowResized(int w, int h);
    void dragEvent(ofDragInfo dragInfo);
    void gotMessage(ofMessage msg);
    
    
    vector<Envelope> e;
    ofPolyline contour;
    ofPolyline wave;
    
    int count = 0;
    vector<ofPoint> pt;
    bool pEnter = false;
    
    string expo;
};
