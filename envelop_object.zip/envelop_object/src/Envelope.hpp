//
//  Envelope.hpp
//  envelop_object
//
//  Created by Peter Mcilwain on 16/06/2016.
//
//

#ifndef Envelope_hpp
#define Envelope_hpp

#include "ofMain.h"


class Envelope {
    
public:
    Envelope();
    
    
    void setup(float x, float y, float w, float h, string n);
    void setup(float x, float y, float w, float h);
    void draw();
    
    void keyPressed(ofKeyEventArgs & args);
    void keyReleased(ofKeyEventArgs & args);
    void mouseMoved(ofMouseEventArgs & args);
    void mouseDragged(ofMouseEventArgs & args);
    void mousePressed(ofMouseEventArgs & args);
    void mouseReleased(ofMouseEventArgs & args);
    void mouseScrolled(ofMouseEventArgs & args);
    void mouseEntered(ofMouseEventArgs & args);
    void mouseExited(ofMouseEventArgs & args);
    
    void enter();
    void edit();
    void findHandle();
    static bool compare(ofPoint &a, ofPoint &b);
    void  makeArray();
    void clearAll();
    float interpolate(float min, float max, float f);
    ofPoint portToOne(ofPoint p);
    
    vector<ofPoint> handle;
    vector<float> contour;
    ofPolyline envi;
    int flag = -1;
    bool selected = false;
    ofRectangle port;
    ofPoint mouse;
    bool enterState = false;
    bool deleteState = false;
    int zoom = 1;
    int scroll = 0;
    float previous = 0;
    
    ofTrueTypeFont	verdana;
    string name;
    
};
#endif /* Envelope_hpp */
