#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    
    e.resize(3);
    e[0].setup(20, 20, 200, 100, "level");
    e[1].setup(20, 140, 200, 100, "frequency");
    e[2].setup(20, 260, 200, 100);
    
    pt.resize(2);
    
    expo = "These envelope objects work similarly to the function object in MaxMSP. \nThey have the following behaviours:\n - COMAND + mousePressed: enters envelope handles \n - SHIFT + mousePressed: deletes a handle \n - BACKSPACE: clears the selected object \n - mousePressed: selects a handle \n - mouseDragged: moves a selected handle \n - UP or DOWN keys: zooms a selected object \n - RIGHT or LEFT keys: scrolls a selected object. \n \nTo use this example: \n 1) enter envelopes in the level and frequency envelope objects \n 2) press p and click and drag in empty space.";
}

//--------------------------------------------------------------
void ofApp::update(){
    
}

//--------------------------------------------------------------
void ofApp::makeEnvelope(){
    contour.clear();
    for(int i = 0; i < e[0].contour.size(); i++){
        int x = ofMap(i, 0, e[0].contour.size() - 1, pt[0].x, pt[1].x);
        float y = ofMap(e[0].contour[i], 0, 1, pt[0].y, pt[1].y);
        ofPoint p(x, y);
        contour.addVertex(p);
    }
}
//--------------------------------------------------------------
void ofApp::makeWave(){
    wave.clear();
    float freq = .8;
    for(int i = 0; i < e[0].contour.size(); i++){
        
        float x = ofMap(i, 0, e[0].contour.size() - 1, pt[0].x, pt[1].x);
        int dex = ofMap(i, 0, e[0].contour.size() - 1, 0, e[1].contour.size() - 1);
        float f = ofMap(e[1].contour[dex], 0, 1, 1, 100);
        float angle = ofMap(x, 0, ofGetWidth(), 0, 1) * f * TWO_PI;
        float y = ofMap(cos(angle) * e[0].contour[i], -1.f, 1.f, pt[0].y, pt[1].y);
        ofPoint p(x, y + 100);
        wave.addVertex(p);
    }
}
//--------------------------------------------------------------
void ofApp::draw(){
    ofBackgroundGradient(90, 0);
    ofSetColor(255);
    contour.draw();
    ofSetColor(255, 255, 0);
    wave.draw();
    
    for(int i = 0; i < e.size(); i++){
        e[i].draw();
    }
    ofSetColor(160);
    ofDrawBitmapString(expo, 20, ofGetHeight() - 190);
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    if(key == 'p'){
        pEnter = true;
    }
    if(key == 'q'){
        cout<<e[1].contour.size()<<endl;
        for(int i =0; i < e[1].contour.size(); i ++){
            cout<<e[1].contour[i]<<endl;
        }
        
    }
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
    pEnter = false;
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){
    
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
    if(pEnter){
        pt[1].set(ofPoint(mouseX, mouseY));
        makeEnvelope();
        makeWave();
    }
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    if(pEnter){
        pt[0].set(ofPoint(mouseX, mouseY));
    }
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    pEnter = false;
}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
    
}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){
    
}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){
    
}
