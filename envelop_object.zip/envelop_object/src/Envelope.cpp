//
//  Envelope.cpp
//  envelop_object
//
//  Created by Peter Mcilwain on 16/06/2016.
//
//

#include "Envelope.hpp"


bool Envelope::compare(ofPoint &a, ofPoint &b){
    return (a.x < b.x);
}


Envelope::Envelope() {
    
}

//--------------------------------------------------------------
void Envelope::setup(float x, float y, float w, float h, string n){
    port.set(x, y, w, h);
    ofRegisterMouseEvents(this);
    ofRegisterKeyEvents(this);
    
    verdana.load("verdana.ttf", 8, true, true);
    verdana.setLineHeight(18.0f);
    verdana.setLetterSpacing(1.037);
    
    name = n;
}

//--------------------------------------------------------------
void Envelope::setup(float x, float y, float w, float h){
    port.set(x, y, w, h);
    ofRegisterMouseEvents(this);
    ofRegisterKeyEvents(this);
    
    verdana.load("verdana.ttf", 8, true, true);
    verdana.setLineHeight(18.0f);
    verdana.setLetterSpacing(1.037);
    
    name = " ";
}

//--------------------------------------------------------------
void Envelope::draw(){
    ofPushView();
    ofViewport(port);
    ofSetupScreen();
    //draw rect
    if(selected){
        ofSetColor(127, 127, 116, 160);
    } else {
        ofSetColor(127, 127, 116, 120);
    }
    ofDrawRectangle(0, 0, ofGetWidth(), ofGetHeight());
    
    //draw grid
    ofSetColor(255, 20);
    ofSetLineWidth(1);
    int space = ofMap(zoom, 1, 10, 20, 1);
    int inc = CLAMP(space, 10, 20);
    
    for(int i = 0; i < port.width / inc; i++){
        float x = i * space * zoom;
        ofDrawLine(x, 20, x, port.height);
    }
    for(int i = 0; i < (port.height - 20) / 10; i++){
        float y = (i * 10) + 20;
        ofDrawLine(0, y, port.width, y);
    }
    
    //draw handles and lines
    envi.clear();
    ofSetColor(255, 255, 0, 140);
    for(int i = 0; i < handle.size(); i++){
        int x = (handle[i].x * zoom) + scroll;
        envi.addVertex(x, handle[i].y);
        ofPoint p(x, handle[i].y);
        ofDrawCircle(p, 3);
    }
    
    // draw envelope
    ofSetColor(255, 140);
    envi.draw();
    
    // draw co-ords
    ofSetColor(140, 140, 0);
    if(handle.size() > 0 && selected){
        ofPoint p(portToOne(handle[flag]));
        string s = "x: " + ofToString(p.x) + "  y: " + ofToString(p.y);
        verdana.drawString(s, 4, 12);
    }
    int x = port.width - verdana.stringWidth(name) - 2;
    verdana.drawString(name, x, 12);
    ofPopView();
}

//--------------------------------------------------------------
void Envelope::keyPressed(ofKeyEventArgs & args){
    switch (args.key) {
        case OF_KEY_COMMAND:
            enterState = true;
            break;
        case OF_KEY_SHIFT:
            enterState = true;
            deleteState = true;
            break;
    }
    if(selected){
        switch (args.key) {
            case OF_KEY_UP:
                enterState = false;
                zoom = CLAMP(zoom + 1, 1, 10);
                scroll = CLAMP(scroll, (port.width * -zoom) + port.width, 0);
                break;
            case OF_KEY_DOWN:
                enterState = false;
                zoom = CLAMP(zoom - 1, 1, 10);
                scroll = CLAMP(scroll, (port.width * -zoom) + port.width, 0);
                break;
            case OF_KEY_RIGHT:
                enterState = false;
                scroll = CLAMP(scroll - (zoom * 4), (port.width * -zoom) + port.width, 0);
                break;
            case OF_KEY_LEFT:
                enterState = false;
                scroll = CLAMP(scroll +  (zoom * 4), (port.width * -zoom) + port.width, 0);
                break;
            case OF_KEY_BACKSPACE:
                clearAll();
                break;
        }
    }
}

//--------------------------------------------------------------
void Envelope::keyReleased(ofKeyEventArgs & args){
    switch (args.key) {
        case OF_KEY_COMMAND:
            enterState = false;
            break;
        case OF_KEY_SHIFT:
            enterState = false;
            deleteState = false;
            break;
    }
}

//--------------------------------------------------------------
void Envelope::mouseMoved(ofMouseEventArgs & args){}

//--------------------------------------------------------------
void Envelope::mouseDragged(ofMouseEventArgs & args){
    int x = (args.x - port.x - scroll) / zoom;
    int y = CLAMP(args.y - port.y, 20, port.height);
    mouse.set(x, y);
    if(selected && handle.size() > 0) {
        edit();
    }
}

//--------------------------------------------------------------
void Envelope::mousePressed(ofMouseEventArgs & args){
    
    if(port.inside(args.x, args.y)){
        int x = (args.x - port.x - scroll) / zoom;
        int y = CLAMP(args.y - port.y, 20, port.height);
        mouse.set(x, y);
        selected = true;
    } else {
        selected = false;
    }
    if(selected && enterState){
        enter();
    } else if(selected && handle.size() > 0){
        findHandle();
    }
}

//--------------------------------------------------------------
void Envelope::mouseReleased(ofMouseEventArgs & args){
    //selected = false;
}

//--------------------------------------------------------------
void Envelope::mouseScrolled(ofMouseEventArgs & args){}

//--------------------------------------------------------------
void Envelope::mouseEntered(ofMouseEventArgs & args){}

//--------------------------------------------------------------
void Envelope::mouseExited(ofMouseEventArgs & args){}


//--------------------------------------------------------------
void Envelope::enter(){
    if(deleteState){
        findHandle();
        if(flag > -1){
            handle.erase( handle.begin() + flag);
        }
    } else {
        handle.push_back(mouse);
    }
    if (handle.size() > 1) {
        ofSort(handle, compare);
    }
    findHandle();
    makeArray();
}

//--------------------------------------------------------------
void Envelope::findHandle(){
    float nearestDistance = 20000;
    for(int i = 0; i < handle.size(); i++) {
        ofPoint cur = handle[i];
        float distance = cur.distance(mouse);
        if(distance < nearestDistance) {
            nearestDistance = distance;
            if(distance < 10){
                flag = i;
                
            } else {
                flag = -1;
            }
        }
    }
}

//--------------------------------------------------------------
void Envelope::edit(){
    int min = 0, max = 0;
    if(flag == 0){
        min = 0;
        max = handle[flag + 1].x - 1;
    } else if(flag < handle.size() - 1){
        min = handle[flag - 1].x + 1;
        max = handle[flag + 1].x - 1;
    } else if(flag < handle.size()){
        min = handle[flag - 1].x + 1;
        max = port.width;
    }
    handle[flag].x = CLAMP(mouse.x, min, max);
    handle[flag].y = CLAMP(mouse.y, 20, port.height);
    
    makeArray();
    
}

//--------------------------------------------------------------
void Envelope::makeArray(){
    int hsize = handle.size();
    
    if(hsize == 1){
        contour.clear();
        contour.resize(1);
        contour[0] = ofMap(handle[0].y, 20, port.height, 1, 0);
    } else {
        int length = handle[hsize - 1].x - handle[0].x;
        int offset = handle[0].x;
        contour.clear();
        contour.resize(length);
        for(int i = 1; i < hsize; i++){
            for(int j = handle[i - 1].x; j < handle[i].x; j++){
                float y = ofMap(j, handle[i - 1].x, handle[i].x, handle[i - 1].y, handle[i].y);
                contour[j - offset] = ofMap(y, 20, port.height, 1, 0);
            }
        }
    }
}

//--------------------------------------------------------------
void Envelope::clearAll(){
    handle.clear();
    contour.clear();
    envi.clear();
}

//--------------------------------------------------------------
float Envelope::interpolate(float min, float max, float per){
    if(handle.size() > 1){
        float x = per * (contour.size() - 1);
        int ix = int(per * (contour.size() - 2));
        float y = ofMap(x, ix, ix + 1, contour[ix], contour[ix + 1]);
        y = ofMap(y, port.height, 20, min, max);
        return y;
    } else {
        return 0;
    }
}

//--------------------------------------------------------------
ofPoint Envelope::portToOne(ofPoint p){
    p.x = ofMap(p.x, 0, port.width, 0, 1);
    p.y = ofMap(p.y, 20, port.height, 1, 0);
    return p;
}

